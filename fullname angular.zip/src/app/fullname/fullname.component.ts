import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-fullname',
  templateUrl: './fullname.component.html',
  styleUrls: ['./fullname.component.css']
})
export class FullnameComponent implements OnInit {
  firstName:string
  lastName:string

  constructor() {
    this.firstName = "Srinivas";
    this.lastName = "Kotha"
   }

  ngOnInit() {
  }

}
